package ar.fiuba.tdd.template.tp0;

/**
 * Created by cbergamo on 15/03/2016.
 */
public class PointRegExp {

    public static boolean isSubRegEx(String exp) {
        if (  ( exp == null ) || ( exp.length() == 0 )  ) {

            return false;
        }
        String primerChar = exp.substring(0,1);
        String charPoint = "." ;
        if ( ( exp.length() >= 1 ) && ( primerChar == charPoint ) ) {
            return true;
        }
        if  ( exp.length() == 2 ) {
            System.out.println("paso");
            String segundoChar = exp.substring(1,2);
            System.out.println((Boolean)Comodin.esComodin(segundoChar));
            if (Comodin.esComodin(segundoChar)){
                return true;
            }
        }
        return false;
    }
}
