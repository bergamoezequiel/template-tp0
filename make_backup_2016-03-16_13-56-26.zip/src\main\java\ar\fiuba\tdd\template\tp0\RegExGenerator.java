package ar.fiuba.tdd.template.tp0;

import java.util.ArrayList;
import java.util.List;

public class RegExGenerator {
    // TODO: Uncomment this field
    //private int maxLength;

    //public RegExGenerator(int maxLength) {
    //    this.maxLength = maxLength;
    //}

    // TODO: Uncomment parameters
    public List<String> generate(/*String regEx, int numberOfResults*/) {
        String scape= String.valueOf(Character.toChars(92));
        return new ArrayList<String>() {
            {
              // add("aaa");
                // add("bbb");

                add("@");
            }
        };
    }
}